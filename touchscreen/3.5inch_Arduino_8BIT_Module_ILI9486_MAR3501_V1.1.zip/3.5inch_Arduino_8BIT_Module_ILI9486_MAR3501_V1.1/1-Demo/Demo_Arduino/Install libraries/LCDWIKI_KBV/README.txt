This is a library for the lcd display.
This library support these lcd controller:
ILI9325 
ILI9328 
ILI9341 
HX8357D 
HX8347G 
HX8347I 
ILI9486 
ST7735S 
 
Check out the file of LCDWIKI KBV lib Requirements for our tutorials and wiring diagrams.

These displays use 8-bit and 16-bit parallel to communicate, 12 or 13 pins are required to interface (RST is optional).
check out the file of lcd_mode.h for switching between 8bit mode and 16 bit mode.
Basic functionally of this library was origianlly based on the demo-code of Adafruit GFX lib and Adafruit TFTLCD lib.  

MIT license, all text above must be included in any redistribution

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder LCDWIKI_KBV. Check that the LCDWIKI_KBV folder contains LCDWIKI_KBV.cpp and LCDWIKI_KBV.h

Place the LCDWIKI_KBV library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE

Also requires the LCDWIKI_GUI library for Arduino. 
https://github.com/lcdwiki/LCDWIKI_gui


